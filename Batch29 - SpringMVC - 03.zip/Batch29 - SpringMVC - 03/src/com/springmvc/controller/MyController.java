package com.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.entity.Student;

@Controller
public class MyController {
	

	@RequestMapping(value="/log")
	public String loginMethod(@RequestParam String user,@RequestParam("pass") String password,Model model) {
		
		System.out.println("LOgin Data : "+user+" "+password );
		model.addAttribute("msg","Successfully Login");
		
		return "success";
		
	}
	
	@RequestMapping(value="/reg")
	public String registerStudent(@ModelAttribute Student s,Model model) {
		
		System.out.println("Student : "+s);
		model.addAttribute("stu",s);
		return "success";
		
	}
	


}
