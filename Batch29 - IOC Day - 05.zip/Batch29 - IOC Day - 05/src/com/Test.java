package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
	
	public static void main(String[] args) {
		
		ApplicationContext apc= new AnnotationConfigApplicationContext(AppConfig.class);
		Student s=apc.getBean("s",Student.class);
//		Student s1=apc.getBean("s",Student.class);
		System.out.println(s);
//		System.out.println(s1.hashCode());
	}

}
