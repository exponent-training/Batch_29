package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {
	
	private int sid;
	
	private String sname;
	
	@Autowired//byType -- byName
	@Qualifier(value="m2")
	private PAddress paddress;

	@Autowired
	@Qualifier(value="m3")
	private PAddress p1address;
	
	public PAddress getP1address() {
		return p1address;
	}

	public void setP1address(PAddress p1address) {
		this.p1address = p1address;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public PAddress getPaddress() {
		return paddress;
	}

	public void setPaddress(PAddress paddress) {
		this.paddress = paddress;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", paddress=" + paddress + ", p1address=" + p1address + "]";
	}

	
}
