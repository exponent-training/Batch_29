package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration//child of @Component
public class AppConfig {
	
	@Bean
	public PAddress m2() {
		PAddress p= new PAddress();
		p.setPinCode(123);
		p.setCity("Tuljapur");
		return p;		
	}
	
	@Bean
	public PAddress m3() {
		PAddress p= new PAddress();
		p.setPinCode(1234);
		p.setCity("Latur");
		return p;		
	}
	
	@Bean(name="s")
	@Scope(value="prototype")
	public Student m1() {
		Student s= new Student();
		s.setSid(11);
		s.setSname("Abc");
		//s.setPaddress(m2());//DI
		return s;
	}
	

}
