package com;

public class College {
	
	private int cid;
	
	private String cname;

	public College(int cid, String cname) {
		super();
		System.out.println("int,String");
		this.cid = cid;
		this.cname = cname;
	}
	
	public College(String cid,String cname) {
		System.out.println("String ,String");
		this.cid=Integer.parseInt(cid);
		this.cname = cname;
		
	}

	@Override
	public String toString() {
		return "College [cid=" + cid + ", cname=" + cname + "]";
	}
	
	

}
