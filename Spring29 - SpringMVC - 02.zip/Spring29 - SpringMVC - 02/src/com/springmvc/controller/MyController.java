package com.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
//@Component
public class MyController {
	
	@RequestMapping(value = "/log")// 3.0
	public String loginUser(@RequestParam("user") String username,@RequestParam("pass") String password,Model model) {
		System.out.println("Hello We are in MyController");
		System.out.println("Username : "+username);
		System.out.println("Password : "+password);
		model.addAttribute("abc","successfully called");
		return "success";//view
	}
	
	

}
