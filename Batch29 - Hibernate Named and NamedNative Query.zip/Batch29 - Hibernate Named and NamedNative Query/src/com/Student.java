package com;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "student_data")

//@NamedQueries({@NamedQuery(query = "from Student where sid=:id1", name = "getSingleStudent"),
//		@NamedQuery(query="select count(sname) from Student",name="countOfStudents")})

@NamedNativeQueries({@NamedNativeQuery(query = "select * from student_data",name="getSingleStudent",resultClass = Student.class)})
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "stu_id")
	private int sid;

	@Column(name = "stu_sname")
	private String sname;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + "]";
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

}
