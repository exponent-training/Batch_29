package com;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Test {
	
	public static void main(String[] args) {
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		
		Session session =sf.openSession();
		
//		Student s= new Student();
//		s.setSname("Pqr");
//		
//		int id=(int)session.save(s);
//		session.beginTransaction().commit();
//		System.out.println(id);
//		
//		Query<Student> query=session.createNamedQuery("getSingleStudent");
//		query.setParameter("id1", 2);
//		Student s=query.getSingleResult();
//		System.out.println(s);
//		
//		Query<Long> query1=session.createNamedQuery("countOfStudents");
//		Long i=query1.getSingleResult();
//		System.out.println(i);
		
		
		Query<Student> query=session.getNamedNativeQuery("getSingleStudent");
		List<Student> slist=query.getResultList();
		System.out.println(slist);
	}

}
