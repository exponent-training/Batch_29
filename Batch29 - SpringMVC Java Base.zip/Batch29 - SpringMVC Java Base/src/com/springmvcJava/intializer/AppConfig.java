package com.springmvcJava.intializer;

import java.util.Properties;

import org.hibernate.cfg.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com")
@EnableWebMvc
public class AppConfig {
	
	@Bean
	public InternalResourceViewResolver viewResolver() {
		
		InternalResourceViewResolver i= new InternalResourceViewResolver();
		i.setSuffix(".jsp");
		return i;
	}
	
	@Bean
	public DriverManagerDataSource ds() {
		DriverManagerDataSource d=new DriverManagerDataSource();
		d.setDriverClassName("com.mysql.jdbc.Driver");
		d.setUrl("jdbc:mysql://loclahost:3306/batch29javaBase");
		d.setUsername("root");
		d.setPassword("root");
		return d;
	}
	
	@Bean
	public LocalSessionFactoryBean ls(){
		LocalSessionFactoryBean l= new LocalSessionFactoryBean();
		l.setDataSource(ds());
		
		Properties p= new Properties();
		p.setProperty(Environment.DIALECT, "org.hibernate.dialect.MySQLDialect");
		p.setProperty(Environment.SHOW_SQL, "true");
		p.setProperty(Environment.HBM2DDL_AUTO, "update");
		
		
		l.setHibernateProperties(p);
		l.setAnnotatedClasses(Student.class);
		return l;
	}
	
	@Bean
	public CommonsMultipartResolver multiPart() {
		return new CommonsMultipartResolver();
	}

}
