package com.springmvcJava.intializer;

public class Student {

}
