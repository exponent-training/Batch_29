package com.springmvc.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.springmvc.entity.Student;
import com.springmvc.serivce.Services;

@Controller
public class MyController {

	@Autowired
	private Services ss;

	@RequestMapping(value = "/log")
	public String loginMethod(@RequestParam String user, @RequestParam("pass") String password, Model model) {

		System.out.println("Login Data : " + user + " " + password);
		if (user.equals("admin") && password.equals("admin@123")) {

			List<Student> list = ss.getAllStudent();
			model.addAttribute("stuList", list);

		} else {
			model.addAttribute("msg", "Invalid Password");
		}
		return "success";

	}

	@RequestMapping(value = "/reg", method = RequestMethod.POST)
	public String registerStudent(@ModelAttribute Student s, @RequestParam MultipartFile fileUp, Model model) {

		System.out.println("Student : " + s);
		try {
			byte[] file=fileUp.getBytes();
			s.setFile(file);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		
		Date d = new Date();

		s.setRegister_Date(d);
		ss.addStudent(s);
		model.addAttribute("stu", s);
		return "index";

	}

	@RequestMapping(value = "/edit")
	public String editData(@RequestParam int sid, Model model) {
		System.out.println("Sid in EditData Method : " + sid);
		Student s = ss.getStudent(sid);
		model.addAttribute("stu", s);
		System.out.println("Before Edit Object : " + s);
		return "edit";
	}

	@RequestMapping(value = "/up")
	public String updateData(@ModelAttribute Student s) {

		System.out.println("Upadte Method : " + s);
		ss.updateData(s);
		return "index";
	}

	@RequestMapping(value = "del")
	public String deleteData(@RequestParam int sid) {
		System.out.println("Student id to delete : " + sid);
		ss.deleteStudent(sid);
		return "index";
	}

}
