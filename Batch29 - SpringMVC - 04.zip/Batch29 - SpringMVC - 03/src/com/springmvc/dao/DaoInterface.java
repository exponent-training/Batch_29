package com.springmvc.dao;

import java.util.List;

import com.springmvc.entity.Student;

public interface DaoInterface {
	
	void addStudentInRepo(Student s);
	
	List<Student> getAllStudentFromRepo();

	Student getStudentData(int sid);
	
	void updateStudentData(Student s);
}
