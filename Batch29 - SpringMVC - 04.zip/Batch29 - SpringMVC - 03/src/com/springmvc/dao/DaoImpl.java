package com.springmvc.dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.entity.Student;

@Repository
public class DaoImpl  implements DaoInterface{

	@Autowired
	private SessionFactory sf;
	
	@Override
	public void addStudentInRepo(Student s) {
		
		System.out.println("In Dao Layer : "+s);
		Session session=sf.openSession();
		session.save(s);
		session.beginTransaction().commit();
		System.out.println("Inserted successfully"); 
		
	}

	@Override
	public List<Student> getAllStudentFromRepo() {
		
		Session session =sf.openSession();
		Query<Student> query=session.createQuery("from Student");
		List<Student> list=query.getResultList();
		return list;
	}

	@Override
	public Student getStudentData(int sid) {
		
		Session session=sf.openSession();
		Student s=session.get(Student.class, sid);
		
		return s;
	}

	@Override
	public void updateStudentData(Student s) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		
		session.update(s);
		session.beginTransaction().commit();
		
		
	}

}
