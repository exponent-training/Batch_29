package com.springmvc.serivce;

import java.util.List;

import com.springmvc.entity.Student;

public interface Services {
	
	void addStudent(Student s);
	
	List<Student> getAllStudent();
	
	Student getStudent(int sid);
	
	void updateData(Student s);

}
