package com.springmvc.serivce;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.dao.DaoInterface;
import com.springmvc.entity.Student;

@Service
public class ServiceImpl implements Services{

	
	@Autowired
	private DaoInterface dao;
	
	@Override
	public void addStudent(Student s) {
		System.out.println("In Service Layer : "+s);
		dao.addStudentInRepo(s);
		
	}

	@Override
	public List<Student> getAllStudent() {
		// TODO Auto-generated method stub
		return dao.getAllStudentFromRepo();
	}

	@Override
	public Student getStudent(int sid) {
		return dao.getStudentData(sid);
		
	}

	@Override
	public void updateData(Student s) {
		// TODO Auto-generated method stub
		dao.updateStudentData(s);
	}

}
