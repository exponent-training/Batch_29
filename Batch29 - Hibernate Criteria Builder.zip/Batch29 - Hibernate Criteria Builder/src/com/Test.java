package com;

import java.util.Arrays;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Test {

	public static void getAllStudentData(SessionFactory sf) {
		Session session = sf.openSession();

		// select * from Student_detail

		// 1. get builder
		CriteriaBuilder builder = session.getCriteriaBuilder();

		// 2. create criteria Query
		CriteriaQuery<Student> criteriaQuery = builder.createQuery(Student.class);

		// 3. copy of table
		Root<Student> root = criteriaQuery.from(Student.class);

		// 4. query build
		criteriaQuery.select(root);

		// 5. provide this query to session
		Query<Student> query = session.createQuery(criteriaQuery);
		List<Student> slist = query.getResultList();
		System.out.println(slist);

	}

	public static void getSingleStudent(SessionFactory sf) {

		Session session = sf.openSession();

		// select * from Student_details where stu_id=?

		// 1. get Builder
		CriteriaBuilder builder = session.getCriteriaBuilder();

		// 2. create criteria Query
		CriteriaQuery<Student> criteriaQuery = builder.createQuery(Student.class);

		// 3. copy of table
		Root<Student> root = criteriaQuery.from(Student.class);

		// 4. build query
		criteriaQuery.select(root).where(builder.equal(root.get("sid"), 2));

		// 5. provide query to session
		Query<Student> query = session.createQuery(criteriaQuery);
		Student s = query.getSingleResult();
		System.out.println(s);

	}

	public static void getIdAndName(SessionFactory sf) {

		Session session = sf.openSession();

		// select stu_id,Stu_name from Student_details where marks=?

		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> criteriaQuery = builder.createQuery(Object[].class);
		Root<Student> root = criteriaQuery.from(Student.class);
		criteriaQuery.multiselect(root.get("sid"), root.get("sname"))
				.where(builder.greaterThan(root.get("marks"), 54.12));

		Query<Object[]> query = session.createQuery(criteriaQuery);
		List<Object[]> slsit = query.getResultList();

		for (Object[] obj : slsit) {
			System.out.println(Arrays.toString(obj));
		}
	}

	public static void getMaxMark(SessionFactory sf) {

		Session session = sf.openSession();

		// select max (marks) from Student_details

		// 1. get Builder
		CriteriaBuilder builder = session.getCriteriaBuilder();

		// 2. create criteria Query
		CriteriaQuery<Double> criteriaQuery = builder.createQuery(Double.class);

		// 3. copy of table
		Root<Student> root = criteriaQuery.from(Student.class);

		// 4. build query
		criteriaQuery.select(builder.max(root.get("marks")));

		// 5. provide query to session
		Query<Double> query = session.createQuery(criteriaQuery);
		Double s = query.getSingleResult();
		System.out.println(s);

	}

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();

//		Student s= new Student();
//		s.setSname("Prerana");
//		
//		s.setMarks(54.12);
//		
//		session.save(s);
//		session.beginTransaction().commit();
//		
//		getAllStudentData(sf);
//		getSingleStudent(sf);
		getIdAndName(sf);
		getMaxMark(sf);

	}

}
