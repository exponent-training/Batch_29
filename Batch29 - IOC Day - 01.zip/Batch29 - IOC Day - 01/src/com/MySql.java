package com;

public class MySql {
	
	private MySql() {
		System.out.println("MySql Constuctor !!");
	}
	
	public void m1() {
		System.out.println("M1 method of Mysql");
	}

}
