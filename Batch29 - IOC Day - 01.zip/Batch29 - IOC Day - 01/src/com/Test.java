package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {

	public static void main(String[] args) {
		
		//2 -- core/j2ee
		//Container --- read xml/cfg file >> Bean creation >> bean lifecycle maintain >> bean distroy
		//Beanfactory // ApplicationContext
		//Lazy loading // Egar
		
		Resource resource= new ClassPathResource("beanCfg.xml");
		BeanFactory bean=new XmlBeanFactory(resource);
		
		System.out.println("-----------------------------------------");
		
		MySql m=(MySql) bean.getBean("m");
//		m.m1();
	}

}
