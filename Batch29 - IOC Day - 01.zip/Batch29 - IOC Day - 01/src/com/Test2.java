package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test2 {
	
	public static void main(String[] args) {
		
//		Apc >> ConfigurableApplicationContext >> ClassPathApplicationContext
		
		ApplicationContext apc=new ClassPathXmlApplicationContext("beanCfg.xml");
		
		System.out.println("________________________________________");
		Oracle o=apc.getBean("o",Oracle.class);
		o.m1();
	}

}
