package com;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

public class Test {
	
	public static void getAllData(SessionFactory sf) {
		
		Session session=sf.openSession();
		
		//select * from student_deatils
		
		Query<Student> query=session.createQuery("from Student");
		List<Student> slist=query.getResultList();
		
		System.out.println(slist);
		
	}
	
	public static void getSingleStudent(SessionFactory sf) {
		Session session =sf.openSession();
		
		//select * from student_deatils where stu_Id=?
		
		Query<Student> query=session.createQuery("from Student where sid=:id1");
		query.setParameter("id1", 2);
		Student s=query.getSingleResult();
		System.out.println(s);
	}
	
	public static void getSingleStudentByUsingName(SessionFactory sf) {
		Session session =sf.openSession();
		
		//select * from student_deatils where stu_name=?
		
		Query<Student> query=session.createQuery("fRom Student where sname=:s1");
		query.setParameter("s1", "PaRimal");
		Student s=query.getSingleResult();
		System.out.println(s);
	}
	
	public static void getSingleStudentSname(SessionFactory sf) {
		Session session =sf.openSession();
		
		//select stu_name from student_deatils where stu_Id=?
		
		Query<String> query=session.createQuery("select sname from Student where sid=:id1");
		query.setParameter("id1", 3);
		String s=query.getSingleResult();
		System.out.println(s);
		
	}
	
	public static void getSingleStudentSnameAndMarks(SessionFactory sf) {
		Session session =sf.openSession();
		
		//select stu_name,stu_marks from student_deatils where stu_Id=?
		//String,Double >> Object[]
		
		Query<Object[]> query=session.createQuery("select sname,marks from Student where sid=:id1");
		query.setParameter("id1", 3);
		Object[] s=query.getSingleResult();
		System.out.println(Arrays.toString(s));
		
	}
	
	public static void getMaxMarks(SessionFactory sf) {
		
		Session session=sf.openSession();
		
		//select max(stu_marks) from student_Deatils
		
		Query<Double> query=session.createQuery("select max(marks) from Student");
		Double max_Marks=query.getSingleResult();
		
		System.out.println(max_Marks);
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		Session session=sf.openSession();
		
//		Student s= new Student();
//		s.setSname("Varsha");
//		s.setMarks(55.78);
//		
//		session.save(s);
//		session.beginTransaction().commit();
		
//		getAllData(sf);
//		getSingleStudent(sf);
//		getSingleStudentByUsingName(sf);
//		getSingleStudentSname(sf);
//		getSingleStudentSnameAndMarks(sf);
//		getMaxMarks(sf);
		
		
		
	}

}
