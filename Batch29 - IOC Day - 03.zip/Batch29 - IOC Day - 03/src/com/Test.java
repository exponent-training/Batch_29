package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	
	public static void main(String[] args) {
		ApplicationContext apc=new ClassPathXmlApplicationContext("com/NewFile.xml");
		
		System.out.println("---------------------------------");
		College c=apc.getBean("c",College.class);
		College c1=apc.getBean("c",College.class);
		
		System.out.println(c.hashCode());
		System.out.println(c.getStudent().hashCode());
		System.out.println("---------------------------------------\n");
		System.out.println(c1.hashCode());
		System.out.println(c1.getStudent().hashCode());
	}

}
